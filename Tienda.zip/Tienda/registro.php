<?php

session_start();


if(isset($_POST['nombre']) && isset($_POST['apellido']) && isset($_POST['email'])) {
    
    $_SESSION['registro'] = array(
        'nombre' => $_POST['nombre'],
        'apellido' => $_POST['apellido'],
        'email' => $_POST['email']
    );

    echo "Registro exitoso.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Cliente</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Registro de Cliente</h1>
        <nav>
            <a href="index.php">Inicio</a>
            
        </nav>
    </header>

    <div class="registro-container">
        <h2>Registrarse como Cliente</h2>
        <form action="procesar_registro.php" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <button type="submit">Registrar</button>
    </form>
    </div>
</body>
</html>