<!DOCTYPE html>
<html lang="es">
<head>
    
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Corporal</h1>
        <h1>Cuidado especializado para tu piel</h1>

        <nav>
            <a href="index.php">Inicio</a>
            <a href="registro.php">Registrarse</a>
            <a href="carrito.php">Carrito</a>
        </nav>
    </header>

    <div class="dproductos">
            <div class="producto">
            <img src="imagenes/jabonf.jpg"width="100" height="100" />
            <h2>Jabón Líquido Corporal Frutos Rojos</h2>
            <p>Limpia delicadamente tu piel manteniéndola hidratada con un aroma a frutos rojos.</p>
            <p>Precio: $225</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Jabón Líquido Corporal Frutos Rojos">
                <input type="hidden" name="precio" value="225">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
           <div class="producto">
            <img src="imagenes/jabonc.jpg"width="100" height="100" />
            <h2>Jabón Líquido Exfoliante Coco Vainilla</h2>
            <p>Limpia y exfolia delicadamente la piel del cuerpo al remover las células muertas, dejándola suave y renovada.</p>
            <p>Precio: $240</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Jabón Líquido Exfoliante Coco Vainilla">
                <input type="hidden" name="precio" value="240">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/cprotectora.jpg"width="100" height="100" />
            <h2>Protector Solar Corporal FPS 50+</h2>
            <p>Protege tu piel diariamente con el Protector solar corporal con FPS 50+, ideal para pieles sensibles, resistente al agua y libre de fragancia.</p>
            <p>Precio: $490</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Protector Solar Corporal FPS 50+">
                <input type="hidden" name="precio" value="490">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/locionf.jpg"width="100" height="100" />
            <h2>Loción Corporal Fruto Rojos</h2>
            <p>Suaviza y nutre la piel con un delicado aroma a frutos rojos.</p>
            <p>Precio: $255</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Loción Corporal Fruto Rojos">
                <input type="hidden" name="precio" value="255">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/locionc.jpg"width="100" height="100" />
            <h2>Loción Corporal Coco Vainilla</h2>
            <p>Hidrata y protege la piel, brindando una sensación de suavidad.</p>
            <p>Precio: $255</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Loción Corporal Coco Vainilla">
                <input type="hidden" name="precio" value="255">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/crema.jpg"width="100" height="100" />
            <h2>Crema para Manos, Cuello y Escote</h2>
            <p>Actúa minimizando la apariencia de manchas oscuras en manos, cuello y escote, causadas por la exposición solar y el envejecimiento.</p>
            <p>Precio: $460</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Crema para Manos, Cuello y Escote">
                <input type="hidden" name="precio" value="460">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
    </div>
</body>
</html>