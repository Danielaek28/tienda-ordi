<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    setcookie('nombre', $nombre, time() + (86400 * 30), "/"); 
    
    setcookie('email', $email, time() + (86400 * 30), "/"); 
    
    header('Location: index.php');
    exit();
}
?>

?>
