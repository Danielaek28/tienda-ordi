<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Capilar</h1>
        <h1>Repara tu cabello de Raiz a puntas</h1>

        <nav>
            <a href="index.php">Inicio</a>
            <a href="registro.php">Registrarse</a>
            <a href="carrito.php">Carrito</a>
        </nav>
    </header>

    <div class="dproductos">
            <div class="producto">
            <img src="imagenes/acondicionador.jpg"width="100" height="100" />
            <h2>Acondicionador con Extractos Herbales de Origen Natural</h2>
            <p>Tu cabello se beneficiará de vitalidad, brillo y suavidad, por los ingredientes acondicionadores y el extracto de Omniplus.</p>
            <p>Precio: $195</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Acondicionador con Extractos Herbales de Origen Natural">
                <input type="hidden" name="precio" value="195">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/scolor.jpg"width="100" height="100" />
            <h2>Shampoo Color Protect</h2>
            <p>El Shampoo Color Protect SEYTÚ ayuda a mantener el tono del cabello teñido y tratado químicamente, protegiéndolo de la raíz a la punta.</p>
            <p>Precio: $295</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Shampoo Color Protect">
                <input type="hidden" name="precio" value="295">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/sextractos.jpg"width="100" height="100" />
            <h2>Shampoo con Extractos Herbales de Origen Natural</h2>
            <p>Dale suavidad, vitalidad, brillo e hidratación a tu cabellera, con este shampoo enriquecido con extracto de Omniplus.</p>
            <p>Precio: $210</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Shampoo con Extractos Herbales de Origen Natural">
                <input type="hidden" name="precio" value="210">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/sextractos.jpg"width="100" height="100" />
            <h2>Shampoo con Extractos Herbales de Origen Natural</h2>
            <p>Dale suavidad, vitalidad, brillo e hidratación a tu cabellera, con este shampoo enriquecido con extracto de Omniplus.</p>
            <p>Precio: $210</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Shampoo con Extractos Herbales de Origen Natural">
                <input type="hidden" name="precio" value="210">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/scuidado.jpg"width="100" height="100" />
            <h2>Shampoo de Cuidado Especial para Cabello Débil</h2>
            <p>Cuida tu cabello con este shampoo que brinda hidratación y acondicionamiento.</p>
            <p>Precio: $295</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Shampoo de Cuidado Especial para Cabello Débil">
                <input type="hidden" name="precio" value="295">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/system.jpg"width="100" height="100" />
            <h2>Shampoo Fortificante</h2>
            <p>Especialmente formulado para ayudar a la recuperación capilar, reducir la caída y aumentar el grosor de la fibra capilar, haciendo lucir un cabello más hidratado, brillante y manejable.</p>
            <p>Precio: $500</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Shampoo Fortificante">
                <input type="hidden" name="precio" value="500">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/slocion.jpg"width="100" height="100" />
            <h2>Loción Capilar Fortificante</h2>
            <p>Estimula y tonifica el cuero cabelludo para obtener un cabello más abundante, hidratado, brillante y manejable.</p>
            <p>Precio: $655</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Loción Capilar Fortificante">
                <input type="hidden" name="precio" value="655">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/mcapilar.jpg"width="100" height="100" />
            <h2>Mascarilla Reparadora Capilar</h2>
            <p>Si tu cabello está seco por químicos, cepillado, rayos del sol u otro elemento, hay una solución: la Mascarilla Reparadora Capilar SEYTÚ.</p>
            <p>Precio: $285</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Mascarilla Reparadora Capilar">
                <input type="hidden" name="precio" value="285">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/gel.jpg"width="100" height="100" />
            <h2>Gel Fijador para el Cabello</h2>
            <p>Este gel contiene extracto de Omniplus, combinación de extractos de plantas, que ayudan a fortalecer y dar brillo a tu cabellera.</p>
            <p>Precio: $140</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Gel Fijador para el Cabello">
                <input type="hidden" name="precio" value="140">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/tinte.jpg"width="100" height="100" />
            <h2>Tinte Permanente sin Amoniaco Rojo</h2>
            <p>Realza el color natural de tu cabello y dale ese toque de intensidad con los Tintes Permanentes sin Amoniaco que SEYTÚ tiene para ti.</p>
            <p>Precio: $285</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Tinte Permanente sin Amoniaco Rojo">
                <input type="hidden" name="precio" value="285">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>

    </div>
</body>
</html>