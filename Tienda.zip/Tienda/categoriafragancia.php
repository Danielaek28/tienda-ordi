<!DOCTYPE html>
<html lang="es">
<head>
   
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        
        <h1>Fragancia</h1>
        <h1>El aroma del Exito</h1>

        <nav>
            <a href="index.php">Inicio</a>
            <a href="registro.php">Registrarse</a>
            <a href="carrito.php">Carrito</a>
        </nav>
    </header>

    <div class="dproductos">
            <div class="producto">
            <img src="imagenes/KV.jpg"width="100" height="100" />
            <h2>Fragancia KENYAVERGARA</h2>
            <p>KENYAVERGARA es una fragancia auténtica con una mezcla de aromas frutales y florales que se combinan con notas resinosas y amaderadas otorgando un toque dulce, que da como resultado una fragancia que refleja frescura, inspiración y libertad.</p>
            <p>Precio: $715</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Fragancia KENYAVERGARA">
                <input type="hidden" name="precio" value="715">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/her.jpg"width="100" height="100" />
            <h2>Fragancia Succesi For Her</h2>
            <p>Fragancia con notas de uva, pera, pimienta rosa, que brindan matices dulces y especiados.</p>
            <p>Precio: $710</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Fragancia Succesi For Her">
                <input type="hidden" name="precio" value="710">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
            <div class="producto">
            <img src="imagenes/him.jpg"width="100" height="100" />
            <h2>Fragancia Succesi For Him</h2>
            <p>Amaderado Especiado Oriental.</p>
            <p>Precio: $710</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Fragancia Succesi For Him">
                <input type="hidden" name="precio" value="710">
                <button type="submit">agregar al carrito</button>
            </form>    

            </div>
    </div>
</body>
</html>